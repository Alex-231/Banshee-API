Server IP: mc.themescape.me:27133

This mod uses an old version of Java.
If you already have Java installed, you'll probably need to uninstall it, and then install the versions provided in \tpi.
If you don't have Java installed, just install the versions supplied in \tpi.