Server IP: mc.themescape.me:27133

This mod uses an old version of Java.
If you already have Java installed, you'll probably need to uninstall it, and then install the versions provided in \tpi.
If you don't have Java installed, just install the versions supplied in \tpi.

At the moment, authentication has been removed, because I'm currently working on an alternative system.
This system will allow for free signup, capes, ears (like deadmau5!), and anything else I want really.

For now though, you can just choose a username.

P.S. 
I'll give you dev branch access if you want!